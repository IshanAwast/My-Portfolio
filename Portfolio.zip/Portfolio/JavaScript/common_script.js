let darkmode = localStorage.getItem("darkmode")
const mode_switcher = document.getElementById("mode_switcher")

const enable = () => {
    document.body.classList.add("darkmode")
    localStorage.setItem("darkmode", "on")
}

const disable = () => {
    document.body.classList.remove("darkmode")
    localStorage.setItem("darkmode", null)
}

darkmode === "on" ? enable() : disable

mode_switcher.addEventListener("click", () => {
    darkmode = localStorage.getItem("darkmode")
    darkmode === "on" ? disable() : enable()
})

// --------------------------------Nav appear on scroll-----------------------------

document.addEventListener("scroll", () =>{
    const nav = document.querySelector("nav");

    if(window.scrollY > 0) {
        nav.classList.add("nav_scroll")
    }
    else{
        nav.classList.remove("nav_scroll")
    }
});