
document.getElementById("to_rps").addEventListener("click", ()=> {
    document.getElementById("rps").style.zIndex = 1;
    document.getElementById("home").style.zIndex = 0;
})

document.getElementById("to_cf").addEventListener("click", ()=> {
    document.getElementById("cf").style.zIndex = 1;
    document.getElementById("home").style.zIndex = 0;
})

document.getElementById("to_cal").addEventListener("click", ()=> {
    document.getElementById("cal").style.zIndex = 1;
    document.getElementById("home").style.zIndex = 0;
})

function back() {
    document.getElementById("rps").style.zIndex = 0;
    document.getElementById("cf").style.zIndex = 0;
    document.getElementById("cal").style.zIndex = 0;
    document.getElementById("home").style.zIndex = 1;
}


// ---------------------------------------Rock Paper Scissors----------------------------------

const choices = ["rock", "paper", "scissors"]
const cpu = document.getElementById("cpu")
const result_display = document.getElementById("result")

function play(pchoice) {
    const cchoice = choices[Math.floor(Math.random() * 3)]
    let result;

    if(pchoice === cchoice){
        result = "Its a tie!"
    }
    else{
        switch(pchoice){
            case "rock":
                result = (cchoice === "scissors") ? "You Win!" : "You Lose!"
                break;
            case "paper":
                result = (cchoice === "rock") ? "You Win!" : "You Lose!"
                break;
            case "scissors":
                result = (cchoice === "paper") ? "You Win!" : "You Lose!"
                break;
        }
    }

    cpu.textContent = `CPU: ${cchoice}`;
    result_display.textContent = result;
}

// ------------------------------------Coin Flip------------------------------------------

const result_cf = document.getElementById("result_cf")
const coin = ["head", "tails"]
function flip(){
    const flip_result = coin[Math.floor(Math.random()*2)]
    result_cf.textContent = `You got ${flip_result}!`
}

// -----------------------------------Calculator-------------------------------------------

const display = document.getElementById("display")

function enterValue(input){
    display.value += input;
}
function clearDisplay(){
    display.value = "";
}
function calculate(){
    display.value = eval(display.value);
}
